import { HeroSection } from "@/components/hero-section";
import { AboutSection } from "@/components/about-section";
import { FactionsSection } from "@/components/factions-section";
import { FeaturesSection } from "@/components/features-section";
import { NewsletterSection } from "@/components/newsletter-section";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { Helmet } from "react-helmet";

export default function Home() {
  return (
    <>
      <Helmet>
        <title>RF Online NewBorn - Coming Soon</title>
        <meta name="description" content="The Hunt is ON for the DRAGONBORN. RF Online NewBorn is an upcoming MMORPG combining fantasy and sci-fi elements in an epic interplanetary war." />
        <meta property="og:title" content="RF Online NewBorn - Coming Soon" />
        <meta property="og:description" content="The Hunt is ON for the DRAGONBORN. Experience the epic interplanetary conflict between three factions in the upcoming RF Online NewBorn MMORPG." />
        <meta property="og:type" content="website" />
      </Helmet>
    
      <div className="min-h-screen flex flex-col">
        <SiteHeader />
        <main>
          <HeroSection />
          <AboutSection />
          <FactionsSection />
          <FeaturesSection />
          <NewsletterSection />
        </main>
        <SiteFooter />
      </div>
    </>
  );
}
