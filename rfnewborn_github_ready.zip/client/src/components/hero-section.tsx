import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";

// Import the image directly using relative path
import rfOnlineCover from '../assets/rf-online-cover.jpg';

export function HeroSection() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.8)), url(${rfOnlineCover})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      <div className="container mx-auto px-6 flex-1 flex flex-col justify-center items-center text-center">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="font-game font-bold text-6xl md:text-8xl text-highlight mb-4 animate-float"
        >
          RF Online <span className="text-[hsl(var(--bellato))]">NewBorn</span>
        </motion.h1>
        
        <motion.p
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="font-game text-xl md:text-3xl text-gray-300 mb-8"
        >
          The Hunt is ON for the <span className="text-[hsl(var(--cora))] font-semibold">DRAGONBORN</span>
        </motion.p>
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="coming-soon-banner text-4xl md:text-6xl mb-12 animate-pulse-slow"
        >
          COMING SOON
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-6"
        >
          <Button 
            size="lg" 
            className="bg-[hsl(var(--bellato))] hover:bg-[hsl(var(--bellato))] hover:opacity-80 text-white font-game font-semibold px-8"
            onClick={() => document.getElementById('subscribe')?.scrollIntoView({ behavior: 'smooth' })}
          >
            GET NOTIFIED
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="border-white/50 hover:border-white text-white font-game font-semibold px-8"
            onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
          >
            LEARN MORE
          </Button>
        </motion.div>
      </div>
      
      <div className="absolute bottom-10 left-0 right-0 text-center">
        <motion.a
          href="#about"
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="inline-block"
        >
          <ChevronDown className="h-8 w-8 text-gray-400 hover:text-white transition" />
        </motion.a>
      </div>
    </section>
  );
}
