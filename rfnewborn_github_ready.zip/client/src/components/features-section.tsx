import { motion } from "framer-motion";
import { Users, Crown, Cog, Shield } from "lucide-react";

export function FeaturesSection() {
  const features = [
    {
      icon: <Users className="text-[hsl(var(--bellato))] text-2xl" />,
      title: "Massive PvP Battles",
      description: "Engage in epic faction wars with hundreds of players fighting simultaneously for control of strategic resources and territory on the Novus planet.",
      color: "bellato"
    },
    {
      icon: <Crown className="text-[hsl(var(--cora))] text-2xl" />,
      title: "Hunt the Dragonborn",
      description: "Track and battle the legendary Dragonborn creatures that roam the landscape, harvesting rare materials and unlocking powerful equipment.",
      color: "cora"
    },
    {
      icon: <Cog className="text-[hsl(var(--accretia))] text-2xl" />,
      title: "Advanced Crafting System",
      description: "Mine resources and craft powerful weapons, armor, and items unique to your faction, with a deep customization system for specialized equipment.",
      color: "accretia"
    },
    {
      icon: <Shield className="text-[hsl(var(--bellato))] text-2xl" />,
      title: "Unique Faction Abilities",
      description: "Each faction features distinct playstyles, from the Bellato's MAU transformations to the Cora's spiritual powers and the Accretia's mechanical enhancements.",
      color: "bellato"
    }
  ];

  return (
    <section id="features" className="py-20 bg-[hsl(var(--dark-surface))] relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-20 left-20 w-64 h-64 rounded-full bg-[hsl(var(--bellato))/0.3] blur-3xl"></div>
        <div className="absolute bottom-40 right-20 w-80 h-80 rounded-full bg-[hsl(var(--cora))/0.3] blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="font-game font-bold text-4xl md:text-5xl mb-16 text-center"
        >
          Game <span className="text-[hsl(var(--cora))]">Features</span>
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-y-16 gap-x-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="flex"
            >
              <div className="flex-shrink-0 mr-6">
                <div className={`w-16 h-16 rounded-full bg-[hsl(var(--${feature.color}))/0.2] flex items-center justify-center`}>
                  {feature.icon}
                </div>
              </div>
              <div>
                <h3 className="font-game text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-gray-300">{feature.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
