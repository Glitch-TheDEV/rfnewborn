import { motion } from "framer-motion";

export function AboutSection() {
  return (
    <section id="about" className="py-20 bg-[hsl(var(--dark-surface))]">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center mb-12"
        >
          <h2 className="font-game font-bold text-4xl md:text-5xl mb-6">
            About <span className="text-[hsl(var(--bellato))]">RF Online</span> NewBorn
          </h2>
          <p className="text-lg text-gray-300 leading-relaxed">
            RF Online NewBorn is a revival of the classic MMORPG that combines fantasy and sci-fi elements in an epic interplanetary war. 
            Three distinct races battle for control over the Novus planet, each with their own unique abilities, technologies, and culture.
          </p>
        </motion.div>
        
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="font-game text-3xl font-semibold mb-4 text-[hsl(var(--cora))]">Epic Interplanetary Conflict</h3>
            <p className="text-gray-300 mb-8 leading-relaxed">
              Experience the thrill of large-scale PvP battles as three factions vie for control of valuable resources. 
              Join the mechanized Accretia Empire, the spiritually advanced Cora Alliance, or the technologically innovative Bellato Union.
            </p>
            
            <h3 className="font-game text-3xl font-semibold mb-4 text-[hsl(var(--bellato))]">Immersive MMORPG Experience</h3>
            <p className="text-gray-300 leading-relaxed">
              Dive into a world where fantasy meets sci-fi with a robust character progression system, 
              crafting, mining, and PvE encounters against fierce creatures including the legendary Dragonborn.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
