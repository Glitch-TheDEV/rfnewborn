import { Link } from "wouter";

export function SiteFooter() {
  return (
    <footer className="bg-[hsl(var(--dark))] py-10 border-t border-gray-800">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <h3 className="text-2xl font-game font-bold text-[hsl(var(--highlight))]">
              RF Online <span className="text-[hsl(var(--bellato))]">NewBorn</span>
            </h3>
            <p className="text-gray-400 mt-2">The Hunt is ON for the DRAGONBORN</p>
          </div>
          
          <div className="flex flex-col md:flex-row gap-8 md:gap-16">
            <div>
              <h4 className="font-game font-semibold text-gray-300 mb-3">Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-[hsl(var(--bellato))] transition">Home</a></li>
                <li><a href="#about" className="hover:text-[hsl(var(--bellato))] transition">About</a></li>
                <li><a href="#factions" className="hover:text-[hsl(var(--bellato))] transition">Factions</a></li>
                <li><a href="#features" className="hover:text-[hsl(var(--bellato))] transition">Features</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-game font-semibold text-gray-300 mb-3">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-[hsl(var(--bellato))] transition">Terms of Service</a></li>
                <li><a href="#" className="hover:text-[hsl(var(--bellato))] transition">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-[hsl(var(--bellato))] transition">Cookie Policy</a></li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="mt-10 pt-6 border-t border-gray-800 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} RF Online NewBorn. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
