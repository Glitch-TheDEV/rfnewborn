import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useMobileMenu } from "@/hooks/use-mobile-menu";

export function SiteHeader() {
  const { isOpen, toggle } = useMobileMenu();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { href: "#about", label: "ABOUT" },
    { href: "#factions", label: "FACTIONS" },
    { href: "#features", label: "FEATURES" },
    { href: "#subscribe", label: "SUBSCRIBE" },
  ];

  return (
    <nav 
      className={`bg-[hsl(var(--dark))/0.8] backdrop-blur-md px-6 py-4 fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? "shadow-md" : ""
      }`}
    >
      <div className="container mx-auto flex justify-between items-center">
        <a href="#" className="text-3xl font-game font-bold text-[hsl(var(--highlight))]">
          RF Online <span className="text-[hsl(var(--bellato))]">NewBorn</span>
        </a>
        
        <div className="hidden md:flex space-x-8">
          {navItems.map((item) => (
            <a 
              key={item.label}
              href={item.href} 
              className="font-game font-medium hover:text-[hsl(var(--bellato))] transition"
            >
              {item.label}
            </a>
          ))}
        </div>
        
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={toggle}
        >
          {isOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </Button>
      </div>
      
      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-[hsl(var(--dark-surface))] absolute w-full left-0 top-full p-4 shadow-lg">
          <div className="flex flex-col space-y-4">
            {navItems.map((item) => (
              <a 
                key={item.label}
                href={item.href} 
                className="font-game font-medium hover:text-[hsl(var(--bellato))] transition py-2"
                onClick={toggle}
              >
                {item.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
