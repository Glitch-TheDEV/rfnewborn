import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  FaDiscord, 
  FaFacebook, 
  FaTwitter, 
  FaYoutube, 
  FaInstagram 
} from "react-icons/fa";

const formSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

type FormValues = z.infer<typeof formSchema>;

export function NewsletterSection() {
  const { toast } = useToast();
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
    },
  });

  const subscription = useMutation({
    mutationFn: (values: FormValues) => {
      return apiRequest("POST", "/api/subscribe", values);
    },
    onSuccess: async (res) => {
      const data = await res.json();
      toast({
        title: "Success",
        description: data.message,
      });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: FormValues) => {
    subscription.mutate(values);
  };

  const socialLinks = [
    { icon: <FaDiscord />, href: "#", label: "Discord" },
    { icon: <FaFacebook />, href: "#", label: "Facebook" },
    { icon: <FaTwitter />, href: "#", label: "Twitter" },
    { icon: <FaYoutube />, href: "#", label: "YouTube" },
    { icon: <FaInstagram />, href: "#", label: "Instagram" },
  ];

  return (
    <section id="subscribe" className="py-20 bg-gradient-to-b from-[hsl(var(--dark-surface))] to-[hsl(var(--dark-surface))/0.5]">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto bg-[hsl(var(--dark))/0.8] p-8 md:p-12 rounded-xl shadow-2xl border border-gray-800"
        >
          <h2 className="font-game font-bold text-3xl md:text-4xl mb-6 text-center">
            Stay Updated on <span className="text-[hsl(var(--bellato))]">RF Online</span> NewBorn
          </h2>
          
          <p className="text-gray-300 text-center mb-8">
            Subscribe to our newsletter to receive the latest news, beta test invitations, 
            and launch information for RF Online NewBorn.
          </p>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col md:flex-row gap-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormControl>
                      <Input
                        placeholder="Enter your email address"
                        {...field}
                        className="bg-[hsl(var(--dark-surface))] border border-gray-700 focus:border-[hsl(var(--bellato))] rounded-md px-4 py-3 text-white"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button 
                type="submit"
                disabled={subscription.isPending}
                className="bg-gradient-to-r from-[hsl(var(--bellato))] to-[hsl(var(--cora))] hover:opacity-90 text-white font-game font-semibold px-8 py-3"
              >
                {subscription.isPending ? "SUBSCRIBING..." : "GET NOTIFIED"}
              </Button>
            </form>
          </Form>
          
          <div className="mt-8 flex justify-center gap-6">
            {socialLinks.map((link, index) => (
              <motion.a
                key={index}
                href={link.href}
                className="text-gray-400 hover:text-[hsl(var(--bellato))] transition"
                aria-label={link.label}
                whileHover={{ scale: 1.2 }}
              >
                <span className="text-2xl">{link.icon}</span>
              </motion.a>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
