import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import bellatoImage from '../assets/bellato.png';
import coraImage from '../assets/cora.png';
import accretiaImage from '../assets/accretia.png';

export function FactionsSection() {
  const factions = [
    {
      name: "Bellato Union",
      color: "bellato",
      description: "A race of small but technologically advanced humanoids who rely on MAUs (Mobile Armor Units) to overcome their physical limitations. Known for their ingenuity and versatility.",
      image: bellatoImage,
      tags: ["Technology", "Versatility"]
    },
    {
      name: "Cora Alliance",
      color: "cora",
      description: "Spiritual and graceful humanoids with deep connections to mystical forces. Masters of force shields, healing, and magical attacks, they blend spirituality with advanced technology.",
      image: coraImage,
      tags: ["Magic", "Spirituality"]
    },
    {
      name: "Accretia Empire",
      color: "accretia",
      description: "A race of mechanized warriors who have abandoned their organic forms for cybernetic enhancements. Physically powerful and resistant to magical attacks, they rely on brute force and advanced weaponry.",
      image: accretiaImage,
      tags: ["Strength", "Mechanical"]
    }
  ];

  return (
    <section id="factions" className="py-20 bg-[hsl(var(--dark))]">
      <div className="container mx-auto px-6">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="font-game font-bold text-4xl md:text-5xl mb-16 text-center"
        >
          Choose Your <span className="text-[hsl(var(--accretia))]">Faction</span>
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {factions.map((faction, index) => (
            <motion.div
              key={faction.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="faction-card bg-gradient-to-b from-[hsl(var(--dark-surface))] to-[hsl(var(--dark))] p-6 rounded-lg border-t-4 border-[hsl(var(--${faction.color}))] shadow-lg"
            >
              <div className="h-64 mb-6 overflow-hidden rounded-lg bg-black/50 flex items-center justify-center">
                <img 
                  src={faction.image}
                  alt={`${faction.name} character`}
                  className="w-auto h-full object-contain transition-transform duration-700 hover:scale-110"
                />
              </div>
              <h3 className={`font-game font-bold text-2xl text-[hsl(var(--${faction.color}))] mb-3`}>
                {faction.name}
              </h3>
              <p className="text-gray-300 mb-4">
                {faction.description}
              </p>
              <div className="flex flex-wrap gap-2">
                {faction.tags.map(tag => (
                  <Badge 
                    key={tag} 
                    className={`bg-[hsl(var(--${faction.color}))/0.2] text-[hsl(var(--${faction.color}))] hover:bg-[hsl(var(--${faction.color}))/0.3]`}
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
