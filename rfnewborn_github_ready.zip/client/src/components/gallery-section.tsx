import { motion } from "framer-motion";

export function GallerySection() {
  const galleryImages = [
    {
      src: "https://images.unsplash.com/photo-1596727147705-61a532a659bd",
      alt: "Epic battle scene from RF Online",
    },
    {
      src: "https://images.unsplash.com/photo-1451187580459-43490279c0fa",
      alt: "Futuristic landscape in RF Online",
    },
    {
      src: "https://images.unsplash.com/photo-1551730459-92db2a308d6a",
      alt: "Character customization in RF Online",
    },
    {
      src: "https://images.unsplash.com/photo-1534972195531-d756b9bfa9f2",
      alt: "Faction warfare in RF Online",
    },
  ];

  return (
    <section className="py-20 bg-[hsl(var(--dark))]">
      <div className="container mx-auto px-6">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="font-game font-bold text-4xl md:text-5xl mb-16 text-center"
        >
          Game <span className="text-[hsl(var(--bellato))]">Gallery</span>
        </motion.h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
              className="overflow-hidden rounded-lg"
            >
              <img 
                src={image.src} 
                alt={image.alt} 
                className="rounded-lg hover:opacity-80 transition duration-500 w-full h-64 object-cover transform hover:scale-105"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
